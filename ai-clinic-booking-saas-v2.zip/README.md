# ClinicOS SaaS v2 — Patient Booking Journey

This build expands the v1 into a complete patient-facing booking journey.

## Patient flow
Chat / quick suggestions
→ service
→ doctor
→ date
→ live time choices
→ patient details + consent
→ optional deposit
→ confirmation / booking ID
→ calendar / WhatsApp reminder actions

It also includes:
- reschedule/cancel conversation entry
- service and price lookup
- doctor lookup
- clinic hours
- emergency escalation message
- voice-input UI hook
- staff/AI handoff concept
- dashboard, patients, billing, analytics and security views

## Important
This is a browser prototype. It demonstrates the complete UX and state transitions but does NOT yet process real patient data, payments, WhatsApp messages, or real AI calls. The production version must connect the flow to the PostgreSQL/authentication/booking API from the foundation package and use a real payment and WhatsApp provider.
