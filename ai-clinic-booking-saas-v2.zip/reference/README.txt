CLINIC AI DEMO — phone app, live AI, Netlify hosting

WHAT IS IN HERE
  index.html                  the whole demo (chat, front desk, revenue report, patient file)
  netlify/functions/chat.js   the AI brain (keeps your API key secret on the server)
  manifest.webmanifest        makes it installable on a phone
  sw.js                       offline support
  icon.svg                    app icon
  netlify.toml                function settings + microphone permission

PUT IT ONLINE (free, no software to install)
  1. Unzip this folder.
  2. Open  app.netlify.com/drop  in Chrome.
  3. Drag the WHOLE FOLDER (not one file) onto the page.
  4. You get a link like  your-name.netlify.app  — that is your live demo.

SWITCH ON LIVE AI (this is what stops the robotic replies)
  1. Get an API key at  console.anthropic.com  (add about $5 of credit).
  2. In Netlify:  Site configuration > Environment variables > Add a variable
        Key:   ANTHROPIC_API_KEY
        Value: sk-ant-...            (your key)
     Optional extras:
        MODEL         claude-haiku-4-5     (cheapest; or claude-sonnet-4-6 for richer replies)
        ACCESS_CODE   anything             (locks the AI endpoint; the page must send it)
  3. Deploys > Trigger deploy > Deploy site.
  4. Open the site. Under the chat it should say "Live AI on your site".
     If it says "add ANTHROPIC_API_KEY", the variable is missing or the deploy did not rerun.

COST
  Roughly $0.02-0.04 per patient conversation on claude-haiku-4-5.
  $5 of credit is about 150 demo conversations.
  Netlify free tier includes 125,000 function calls a month.

USE IT AS AN APP ON YOUR PHONE
  iPhone/Safari:  open the link > Share > Add to Home Screen.
  Android/Chrome: menu > Add to home screen, or tap the green "Install app" button.

UPDATING THE APP AFTER CHANGES
  1. Netlify > your site > Deploys > drag the folder onto the drop area again.
  2. On the phone, close the app fully (swipe it away) and reopen it.
  3. Check Clinic setup > bottom line shows the version number.
     If it still shows the old version, pull down to refresh, or open the site in
     Safari/Chrome once, which clears the offline cache, then reopen the app icon.
