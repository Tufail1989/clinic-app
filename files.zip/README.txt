CLINIC AI — clinic SaaS console (v1.4)
Dashboard, AI receptionist, appointments, patients, billing, analytics, settings.

WHAT IS IN HERE
  index.html                  the whole app
  api/chat.js                 AI endpoint for VERCEL            (/api/chat)
  functions/api/chat.js       AI endpoint for CLOUDFLARE PAGES  (/api/chat)
  netlify/functions/chat.js   AI endpoint for NETLIFY           (/.netlify/functions/chat)
  manifest.webmanifest, sw.js, icon.svg      installable phone app + offline
  _headers                    microphone permission on Cloudflare
  netlify.toml                microphone permission + function settings on Netlify

The page finds whichever endpoint exists, so the SAME folder works on all three hosts.

------------------------------------------------------------------
OPTION A — GITHUB + VERCEL  (easiest if Cloudflare keeps making Workers)

 1. github.com  >  sign up  >  New repository  >  name it clinic-app  >  Create.
 2. On the repo page: "uploading an existing file"  >  drag the WHOLE UNZIPPED
    FOLDER's CONTENTS in (index.html, api/, functions/, netlify/, sw.js, icons,
    manifest, _headers, netlify.toml)  >  Commit changes.
 3. vercel.com  >  Continue with GitHub  >  Add New  >  Project  >  Import clinic-app.
 4. Framework preset: Other.  Leave build settings empty.  Deploy.
 5. You get  https://clinic-app-xxxx.vercel.app
 6. Add the key later:  Project  >  Settings  >  Environment Variables
        ANTHROPIC_API_KEY = sk-ant-...     (then Deployments > ... > Redeploy)
 7. Check  /api/chat   -> should show  "ai":true (or "ai":false until the key is set)

 Updating: edit files on GitHub (or re-upload) and Vercel redeploys automatically.
 Vercel Hobby is free and does not charge per deploy.

------------------------------------------------------------------
OPTION B — CLOUDFLARE PAGES  (recommended: unlimited bandwidth,
100,000 function calls/day, 500 builds/month on the free plan)

 1. Sign up at  dash.cloudflare.com  (free).
 2. Left menu: Workers & Pages  >  Create  >  switch to the PAGES tab at the top
    (Workers is selected by default)  >  "Upload assets".
    IMPORTANT: if the address you end up with contains workers.dev, you created a
    Worker by mistake. Delete it and start again on the Pages tab, or use Option A.
 3. Name the project, e.g. aiclinicbooking. Drag the WHOLE FOLDER in. Deploy.
 4. Add your key:  project  >  Settings  >  Variables and secrets  >  Add
        Type:  Secret
        Name:  ANTHROPIC_API_KEY
        Value: sk-ant-...
    Optional:  MODEL = claude-haiku-4-5      ACCESS_CODE = anything you like
 5. Deployments  >  ...  >  Retry deployment   (variables only apply to a new build)
 6. Open  https://YOUR-PROJECT.pages.dev/api/chat   -> should show  "ai":true
 7. Open the site. Under the chat it should say "Live AI on your site".

 Updating later: Pages > your project > Create new deployment > drag the folder again.

------------------------------------------------------------------
OPTION C — NETLIFY  (free plan = 300 credits/month; each deploy costs
15 credits, so about 20 deploys a month, then the site pauses)

 1. app.netlify.com/drop  >  drag the WHOLE FOLDER.
 2. Site configuration > Environment variables > ANTHROPIC_API_KEY = sk-ant-...
 3. Deploys > Trigger deploy > Deploy site.
 4. Check  /.netlify/functions/chat   -> should show  "ai":true

 Tip: deploy to Netlify only when you have real changes; test locally first.

------------------------------------------------------------------
PHONE APP
  iPhone/Safari:  open the link > Share > Add to Home Screen.
  Android/Chrome: menu > Add to home screen (or the green Install app button).
  After deploying an update: close the app fully, reopen, and check the version
  number in the sidebar and in Clinic setup.

COSTS
  Hosting: free on both.
  AI: about $0.02-0.04 per patient conversation on claude-haiku-4-5.
  Set a monthly spend limit in console.anthropic.com.
