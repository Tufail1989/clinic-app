// Cloudflare Pages Function — same brain as the Netlify one.
// Lives at /api/chat once deployed. The API key is set in the Pages dashboard
// (Settings > Variables and Secrets > ANTHROPIC_API_KEY), never in the page.

function buildSystem(c, history) {
  const cut = (v, n) => String(v || "").slice(0, n);
  const cur = cut(c.cur, 10);
  const services = cut(c.services, 1200)
    .split("\n").map(l => l.trim()).filter(Boolean)
    .map(l => {
      const i = l.indexOf(":");
      return i < 0 ? `- ${l}` : `- ${l.slice(0, i).trim()}: ${cur} ${l.slice(i + 1).trim()}`;
    }).join("\n");
  const phone = cut(c.phone, 40);

  return `You are the WhatsApp receptionist for ${cut(c.name, 80) || "the clinic"}, a clinic in ${cut(c.city, 60)}. You are warm, brief and human — never robotic, and you never repeat a greeting the patient has already had.
Phone: ${phone}. Timings: ${cut(c.hours, 120)}.${c.doctors ? ` Doctors: ${cut(c.doctors, 200)}.` : ""}
Prices (ranges; the doctor confirms the exact price after examining the patient):
${services || "- Ask the patient to call for prices."}
${c.notes ? `Other notes: ${cut(c.notes, 400)}` : ""}
${c.faq ? `Clinic FAQs (use these answers when they fit):\n${cut(c.faq, 1200)}` : ""}
${history ? `This patient's history at the clinic: ${cut(history, 500)}` : ""}

Your job: answer naturally, collect what you need for a booking (what they need, their name, urgency, preferred day and time), then say the front desk will confirm. Never claim a slot is already confirmed.

Style: real WhatsApp messages, one to three short sentences, no markdown or bullet lists. Mirror the patient's language exactly — Roman Urdu stays Roman Urdu, Urdu script stays Urdu script. One question at a time. Never send the same sentence twice.

Safety: never diagnose, never interpret photos or reports, never name medicines or doses — the doctor must examine them. Emergency signs (spreading facial or neck swelling, trouble breathing or swallowing, bleeding that will not stop, chest pain, knocked-out tooth, major injury, fits, high fever in a small child): tell them to call ${phone} now, and to go to the nearest emergency department if breathing or swallowing is affected, then set status to "Emergency - staff alerted". Never invent prices, doctors, discounts or available slots.

Reply with ONLY a JSON object, no other text:
{"reply": "your message to the patient", "lead": {"name": "", "treatment": "", "urgency": "Emergency|Same day|Within 48 hours|Routine|", "preferred_time": "", "status": ""}}
Leave a field as an empty string when it is not known yet.`;
}

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), { status, headers: { "content-type": "application/json", "cache-control": "no-store" } });

export async function onRequestGet({ env }) {
  return json({ ok: true, ai: !!env.ANTHROPIC_API_KEY, needsCode: !!env.ACCESS_CODE, model: env.MODEL || "claude-haiku-4-5", host: "cloudflare" });
}

export async function onRequestPost({ request, env }) {
  if (env.ACCESS_CODE && request.headers.get("x-access-code") !== env.ACCESS_CODE) {
    return json({ error: "Access code required" }, 401);
  }
  if (!env.ANTHROPIC_API_KEY) {
    return json({ error: "ANTHROPIC_API_KEY is not set in this project's variables" }, 500);
  }

  let body;
  try { body = await request.json(); } catch { return json({ error: "Bad JSON" }, 400); }

  const messages = (Array.isArray(body.messages) ? body.messages : [])
    .slice(-24)
    .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .map(m => ({ role: m.role, content: m.content.slice(0, 1500) }));
  if (!messages.length) return json({ error: "No messages" }, 400);

  try {
    const res = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": env.ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({
        model: env.MODEL || "claude-haiku-4-5",
        max_tokens: 400,
        system: buildSystem(body.clinic || {}, body.history || ""),
        messages,
      }),
    });

    if (!res.ok) return json({ error: `Claude API ${res.status}`, detail: (await res.text()).slice(0, 300) }, 502);

    const data = await res.json();
    const text = (data.content || []).filter(b => b.type === "text").map(b => b.text).join("").trim();

    let parsed = null;
    try {
      const clean = text.replace(/```json|```/g, "").trim();
      parsed = JSON.parse(clean.slice(clean.indexOf("{"), clean.lastIndexOf("}") + 1));
    } catch { parsed = null; }

    return json({
      reply: (parsed && parsed.reply) || text || "Sorry, could you say that again?",
      lead: (parsed && parsed.lead) || {},
      usage: data.usage || null,
    });
  } catch (e) {
    return json({ error: "Upstream failure", detail: String(e && e.message).slice(0, 200) }, 502);
  }
}
